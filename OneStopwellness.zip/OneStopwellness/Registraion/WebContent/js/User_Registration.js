       
       function validate() {
      
          if( document.Insert.First_Name.value == "" || document.Insert.First_Name.match(/^[0-9]+$/) ){
             alert( "Please provide your First name!" );
             document.Insert.First_Name.focus() ;
             document.getElementById("First_Name").style.borderColor="red";
             return false;
          }     
          if( document.Insert.Last_Name.value == "" ) {
              alert( "Please provide your name!" );
              document.Insert.Last_Name.focus() ;
              document.getElementById("Last_Name").style.borderColor="red";
              return false;
           }     
      
             if( document.Insert.Age.value == "" || isNaN(document.Insert.Age.value)) {
             alert( "Please provide Valid Age!" );
             document.Insert.Age.focus() ;
             return false;
          }
          if( document.Insert.Zip_COde.value == "" || isNaN( document.Insert.Zip.value ) ||
             document.Insert.Zip_Code.value.length != 5 ) {
            
             alert( "Please provide a zip in the format #####." );
             document.Insert.Zip_Code.focus() ;
            return false;
         }
        if( document.Insert.Country.value == "-1" ) {
            alert( "Please provide your country!" );
            return false;
          }
          return( true );
      }  
     

