package com.rays.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.rays.connection.ConnectionFactory;
import com.rays.model.Diagnosis;

public class Diagnosis_Impl implements DiagnosisDAO {
	Connection con=null;
    public Diagnosis_Impl() {
           // TODO Auto-generated constructor stub
           this.con=ConnectionFactory.openConn();
    }
	@Override
	public int insertDiagnosis(Diagnosis ds) {
		int count=0;
        try {

                        PreparedStatement ps=con.prepareStatement("insert into diagnosis values(?,?,?,?,?,?)");
                        ps.setInt(1, ds.getPatiant_id());
                        ps.setString(2, ds.getDisease());
                        ps.setString(3, ds.getPrescription());
                        ps.setInt(4, ds.getDoctor_id());
                        ps.setDate(5, new java.sql.Date(ds.getDateandtime().getTime()));
                        ps.setInt(6, ds.getHospital_id());
                        count=ps.executeUpdate();
        }catch (Exception e) {
                        System.out.println("Error in Insert diagnosis "+e);
        }
        return count;
	}
	@Override
	public Diagnosis getReport(int user_id) {
		Diagnosis d=null;
		try {
            PreparedStatement ps=con.prepareStatement("select * from diagnosis where patiant_id=?");
            ps.setInt(1, user_id);            
            ResultSet rs=ps.executeQuery();
            if(rs.next())
            {
            	d=new Diagnosis(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getDate(5), rs.getInt(6));
            	System.out.println("Data Written...");
            }              
		}catch (Exception e) {
            System.out.println("Error in get  diagnosis Report "+e);
}
		return d;
	}

}
