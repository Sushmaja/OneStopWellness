package com.rays.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.rays.connection.ConnectionFactory;
import com.rays.model.Hospital_Registration;
public class Hospital_Registration_Impl implements Hospital_RegistrationDAO {

       Connection con=null;
       public Hospital_Registration_Impl() {
              // TODO Auto-generated constructor stub
              this.con=ConnectionFactory.openConn();
       }
     
     

       @Override
       public int storeHospital(Hospital_Registration hr) {
              int status=0;
              try {
                     PreparedStatement ps=con.prepareStatement("insert into hospital_register (Hospital_Name,Address_linea,Address_lineb,City,State,Pin,Certifications,Suuccessful_operations,achievements)values(?,?,?,?,?,?,?,?,?)");
                  //   ps.setInt(1, hr.getHospital_id());
                     ps.setString(1, hr.getHospital_Name());
                     ps.setString(2, hr.getAddress_linea());
                     ps.setString(3, hr.getAddress_lineb());
                     ps.setString(4, hr.getCity());
                     ps.setString(5, hr.getState());
                     ps.setLong(6, hr.getPin());
                     ps.setString(7, hr.getCertifications());
                     ps.setString(8, hr.getSuccessful_operations());
                     ps.setInt(9, hr.getAchievements());
                    // ps.setInt(10, 0);
                     status=ps.executeUpdate();
              }catch (Exception e) {
                     System.out.println("Error in Insert hospital details "+e);
                     status=0;
              }
              return status;
       }



	@Override
	public List<Hospital_Registration> showAllHospital() {

			List<Hospital_Registration> hospitalList=new ArrayList<Hospital_Registration>();
			try {
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select * from hospital_register");
				while(rs.next())
				{
					Hospital_Registration hr=new Hospital_Registration();
					hr.setHospital_id(rs.getInt(1));
					hr.setHospital_Name(rs.getString(2));
					hr.setAddress_linea(rs.getString(3));
					hr.setAddress_lineb(rs.getString(4));
					hr.setCity(rs.getString(5));
					hr.setState(rs.getString(6));
					hr.setPin(rs.getInt(7));
					hr.setCertifications(rs.getString(8));
					hr.setSuccessful_operations(rs.getString(9));
					hr.setAchievements(rs.getInt(10));
					hr.setStatus(rs.getInt(11));
					hospitalList.add(hr);
				}
			} catch (Exception e) {
				// TODO: handle exception
			}
		
		return hospitalList;
	}



	@Override
	public int updateStatus(int hopital_id, int status) {
		int count=0;
        try {
               PreparedStatement ps=con.prepareStatement("update hospital_register set status=? where Hospital_id=?");
               ps.setInt(2, hopital_id);            
               ps.setInt(1, status); 
               count=ps.executeUpdate();
        }catch (Exception e) {
               System.out.println("Error in Updating hospital status"+e);
               count=0;
        }
        return count;
	}



	@Override
	public int validateHospital(String hospital_id) {
		int status=0;
		try {
			  						
			 java.sql.PreparedStatement ps = con.prepareStatement("Select hospital_id from hospital_register where hospital_id=?");
			 ps.setString(1,hospital_id);
			
				
				// TODO Auto-generated catch block
			
					 java.sql.ResultSet rs = ps.executeQuery();
			 if(rs.next())
			 {
				status=1;
			 }
			 else
			 {
				 status=0;
			 }
			 
		}
			catch(Exception e)
			{
				System.out.println("Error in Validate Hospital :"+e);
			}
		return status;
	}
	}



	

