package com.rays.dao;

import com.rays.model.Diagnosis;


public interface DiagnosisDAO {
	public int insertDiagnosis(Diagnosis ds);
	public Diagnosis getReport(int user_id);
}
