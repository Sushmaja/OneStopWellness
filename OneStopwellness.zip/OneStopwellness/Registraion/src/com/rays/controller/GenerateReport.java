package com.rays.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.rays.dao.DiagnosisDAO;
import com.rays.dao.Diagnosis_Impl;
import com.rays.model.Diagnosis;

/**
 * Servlet implementation class GenerateReport
 */
@WebServlet("/GenerateReport")
public class GenerateReport extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GenerateReport() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/pdf;charset=UTF-8");		
        response.addHeader("Content-Disposition", "inline; filename=" + "cities.pdf");
        ServletOutputStream out = response.getOutputStream();
        HttpSession hs=request.getSession();
        String user_id1=(String)hs.getAttribute("User_ID");
        int user_id=Integer.parseInt(user_id1);
        DiagnosisDAO dd= new Diagnosis_Impl();
        Diagnosis dignosis = dd.getReport(user_id);

        if(dignosis!=null)
        {
        ByteArrayOutputStream baos = GeneratePdf.getPdfFile(dignosis);
        baos.writeTo(out);
        }else
        {
        	System.out.println("Report Not Found");
        	//pw.print("Report Not Found...Contact Hospital Admin");
        	//request.getRequestDispatcher("Home_Page.jsp").include(request, response);
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
