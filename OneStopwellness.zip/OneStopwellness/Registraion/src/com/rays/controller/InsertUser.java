package com.rays.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.rays.dao.User_RegistrationDAO;
import com.rays.dao.User_Registration_Impl;
import com.rays.model.User_Registration;

/**
 * Servlet implementation class InsertUser
 */
@WebServlet("/InsertUser")
public class InsertUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
        //int user_id=Integer.parseInt(request.getParameter("User_Id"));
        String first_name=request.getParameter("First_Name");
        String last_Name=request.getParameter("Last_Name");
        int age=Integer.parseInt(request.getParameter("Age"));
        String gender=request.getParameter("Gender");
        long contact_Number=Long.parseLong(request.getParameter("Contact_Number"));
        String address=request.getParameter("Address");
        String city=request.getParameter("City");
        long zip_code=Long.parseLong(request.getParameter("Zip_Code"));
        String Password=request.getParameter("Password");
        User_Registration ur=new User_Registration(first_name, last_Name, age, gender, contact_Number, address, city,  zip_code, Password);
        User_RegistrationDAO urdao=new User_Registration_Impl();
        int status=urdao.insertUser(ur);
        if(status==1)
        {
        				int user_id=urdao.getUserId(contact_Number);
        			   pw.println("You are successfully registered. You can Login now by using your User Id\n");
                       pw.println("Your User Id is :\n"+user_id);
                       pw.println("Please note down your User Id for future reference\n");
                        
                        request.getRequestDispatcher("Login.jsp").include(request, response);
        }
        else if(status==2)
        {
                        pw.println("Mobile NUmber Already Registered...");
                        request.getRequestDispatcher("User_Registration.jsp").include(request, response);
        }

	}

}
