package com.rays.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.rays.dao.Hospital_RegistrationDAO;
import com.rays.dao.Hospital_Registration_Impl;
import com.rays.dao.User_RegistrationDAO;
import com.rays.dao.User_Registration_Impl;

/**
 * Servlet implementation class Loginuser
 */
@WebServlet("/Loginuser")
public class Loginuser extends HttpServlet {

	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public Loginuser() {
    
       
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @return 
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String User_id=request.getParameter("User_id");
		String Password=request.getParameter("Password");
		HttpSession hs=request.getSession();
	    if(User_id.equals("Super")&& Password.equals("Super"))
		{
			RequestDispatcher rd = request.getRequestDispatcher("Dashboard.jsp");
			rd.forward(request, response);
		}
	    else if(Password.equals("Hospital"))
	    {
	    	{
	    		Hospital_RegistrationDAO hd=new Hospital_Registration_Impl();
	    		int status=hd.validateHospital(User_id);
	    		
	    		if(status==1)
	    		{
	    			hs.setAttribute("Hospital_ID", User_id);
	    			RequestDispatcher rd = request.getRequestDispatcher("DisplayHospital.jsp");
	    			rd.forward(request, response);
	    		}
	    		else
	    		{
	    			
	    			pw.println("Hospital Id or Password is wrong. Please Login again..");
	    			RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
	    			rd.include(request, response);
	    		}
	    		}
	    }
		else
			
		{
		User_RegistrationDAO ud=new User_Registration_Impl();
		int status=ud.validateUser(User_id, Password);
		
		if(status==1)
		{
			hs.setAttribute("User_ID", User_id);
			RequestDispatcher rd = request.getRequestDispatcher("Home_Page.jsp");
			rd.forward(request, response);
		}
		else
		{
			
			pw.println("User Id or Password is wrong. Please Login again..");
			RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
			rd.include(request, response);
		}
		}
			}
	}