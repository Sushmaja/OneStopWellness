package com.rays.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.rays.dao.DiagnosisDAO;
import com.rays.dao.Diagnosis_Impl;
import com.rays.dao.DoctorDAO;
import com.rays.dao.Doctor_Impl;
import com.rays.model.Diagnosis;
import com.rays.model.Doctor;

/**
 * Servlet implementation class InsertDiagnosis
 */
@WebServlet("/InsertDiagnosis")
public class InsertDiagnosis extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertDiagnosis() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	
		PrintWriter pw=response.getWriter();
		int patiant_id=Integer.parseInt(request.getParameter("patiant_id"));
        String disease=request.getParameter("disease");
        String Prescription=request.getParameter("Prescription");
        int doctor_id=Integer.parseInt(request.getParameter("doctor_id"));
       String dateandtime=request.getParameter("dateandtime");
       SimpleDateFormat sd=new SimpleDateFormat("dd/MM/yyyy");
       Date dd=null;
	try {
		dd = sd.parse(dateandtime);
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
       int hospital_id=Integer.parseInt(request.getParameter("hospital_id"));
        Diagnosis ds=new Diagnosis(patiant_id, disease, Prescription, doctor_id, dd, hospital_id);
       DiagnosisDAO DD=new Diagnosis_Impl();
       int count=DD.insertDiagnosis(ds);
        if(count==1)
        {
                        pw.println("Added Successfully");
        }
        else
        {
                        pw.println("Failed Adding");
        }
	}}


