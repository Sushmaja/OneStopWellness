package com.rays.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.mysql.jdbc.Driver;

public class ConnectionFactory {
                
                static Connection con;
                public static Connection openConn()
                {
                                try {
                                                DriverManager.registerDriver(new Driver());
                                                con=DriverManager.getConnection("jdbc:mysql://localhost:3306/onestopwellness", "root", "root");
                                          /*      Statement st=con.createStatement();
                                            PreparedStatement ps=con.prepareStatement("");
                                       ResultSet rs=ps.executeQuery();
                                       rs.cl*/
                                                
                                } catch (Exception e) {
                                                System.out.println("Error in open Connection :"+e);
                                }
                                return con;
                }
                public static void closeConn()
                {
                                try {
                                                con.close();
                                } catch (Exception e) {
                                                System.out.println("Error in close Connection :"+e);
                                }
                }

}
