package com.rays.model;

import java.util.Date;

public class Diagnosis {
private int patiant_id;
private String disease;
private String Prescription;
private int doctor_id;
private Date dateandtime;
private int hospital_id;
public int getPatiant_id() {
	return patiant_id;
}
public void setPatiant_id(int patiant_id) {
	this.patiant_id = patiant_id;
}
public String getDisease() {
	return disease;
}
public void setDisease(String disease) {
	this.disease = disease;
}
public String getPrescription() {
	return Prescription;
}
public void setPrescription(String prescription) {
	Prescription = prescription;
}
public int getDoctor_id() {
	return doctor_id;
}
public void setDoctor_id(int doctor_id) {
	this.doctor_id = doctor_id;
}
public Date getDateandtime() {
	return dateandtime;
}
public void setDateandtime(Date dateandtime) {
	this.dateandtime = dateandtime;
}
public int getHospital_id() {
	return hospital_id;
}
public void setHospital_id(int hospital_id) {
	this.hospital_id = hospital_id;
}
public Diagnosis() {
	super();
	// TODO Auto-generated constructor stub
}
public Diagnosis(int patiant_id, String disease, String prescription, int doctor_id, Date dateandtime,
		int hospital_id) {
	super();
	this.patiant_id = patiant_id;
	this.disease = disease;
	Prescription = prescription;
	this.doctor_id = doctor_id;
	this.dateandtime = dateandtime;
	this.hospital_id = hospital_id;
}

}
