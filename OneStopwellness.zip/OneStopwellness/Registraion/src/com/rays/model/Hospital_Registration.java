package com.rays.model;

public class Hospital_Registration {
       
       private int hospital_id;
       private String hospital_Name;
       private String address_linea;
       private String address_lineb;
       private String city;
       private String state;
       private long pin;
       private String certifications;
       private String Successful_operations;
       private int achievements;
       private int status;
       public int getHospital_id() {
              return hospital_id;
       }
       public void setHospital_id(int hospital_id) {
              this.hospital_id = hospital_id;
       }
       public String getHospital_Name() {
              return hospital_Name;
       }
       public void setHospital_Name(String hospital_Name) {
              this.hospital_Name = hospital_Name;
       }
       public String getAddress_linea() {
              return address_linea;
       }
       public void setAddress_linea(String address_linea) {
              this.address_linea = address_linea;
       }
       public String getAddress_lineb() {
              return address_lineb;
       }
       public void setAddress_lineb(String address_lineb) {
              this.address_lineb = address_lineb;
       }
       public String getCity() {
              return city;
       }
       public void setCity(String city) {
              this.city = city;
       }
       public String getState() {
              return state;
       }
       public void setState(String state) {
              this.state = state;
       }
       public long getPin() {
              return pin;
       }
       public void setPin(long pin) {
              this.pin = pin;
       }
       public String getCertifications() {
              return certifications;
       }
       public void setCertifications(String certifications) {
              this.certifications = certifications;
       }
       public String getSuccessful_operations() {
              return Successful_operations;
       }
       public void setSuccessful_operations(String successful_operations) {
              Successful_operations = successful_operations;
       }
       public int getAchievements() {
              return achievements;
       }
       public void setAchievements(int achievements) {
              this.achievements = achievements;
       }
       public Hospital_Registration() {
              super();
              // TODO Auto-generated constructor stub
       }
       public Hospital_Registration(String hospital_Name, String address_linea, String address_lineb,
                     String city, String state, long pin, String certifications, String successful_operations,
                     int achievements) {
              super();
             // this.hospital_id = hospital_id;
              this.hospital_Name = hospital_Name;
              this.address_linea = address_linea;
              this.address_lineb = address_lineb;
              this.city = city;
              this.state = state;
              this.pin = pin;
              this.certifications = certifications;
              this.Successful_operations = successful_operations;
              this.achievements = achievements;
       }
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}

       
}
