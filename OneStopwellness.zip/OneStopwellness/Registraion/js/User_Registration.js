       
       function validate() {
      
          if( document.InsertUser.First_Name.value == "" ) {
             alert( "Please provide your First name!" );
             document.InsertUser.First_Name.focus() ;
             document.getElementById("First_Name").style.borderColor="red";
             return false;
          }     
          if( document.InsertUser.Last_Name.value == "" ) {
              alert( "Please provide your name!" );
              document.InsertUser.Last_Name.focus() ;
              document.getElementById("Last_Name").style.borderColor="red";
              return false;
           }     
      
             if( document.InsertUser.Age.value == "" || isNaN(document.InsertUser.Age.value)) {
             alert( "Please provide Valid Age!" );
             document.InsertUser.Age.focus() ;
             return false;
          }
          if( document.InsertUser.Zip_COde.value == "" || isNaN( document.InsertUser.Zip.value ) ||
             document.InsertUser.Zip_Code.value.length != 5 ) {
            
             alert( "Please provide a zip in the format #####." );
             document.InsertUser.Zip_Code.focus() ;
            return false;
         }
        if( document.InsertUser.Country.value == "-1" ) {
            alert( "Please provide your country!" );
            return false;
          }
          return( true );
      }  
     

